

//export {connectSerial, serialResultsDiv, sendSerialLine, sendCharacterNumber};
