import ApexCharts from "apexcharts";
window.Promise ||
document.write('<script src="https://cdn.jsdelivr.net/npm/promise-polyfill@8/dist/polyfill.min.js"><\/script>');
window.Promise ||
document.write('<script src="https://cdn.jsdelivr.net/npm/eligrey-classlist-js-polyfill@1.2.20171210/classList.min.js">' +
  '<\/script>');
window.Promise ||
document.write('<script src="https://cdn.jsdelivr.net/npm/findindex_polyfill_mdn"><\/script>');

let packs_num = [];

let vals = {
  height: [],
  press: [],
  acc: [],
  temp: []
};

var height_graph = {
  series: [{
    data: vals.height
  }],
  chart: {
  id: 'realtime',
  height: 350,
  type: 'line',
  animations: {
    enabled: true,
    easing: 'linear',
    dynamicAnimation: {
      speed: 1000
    }
  },
  toolbar: {
    show: false
  },
  zoom: {
    enabled: false
  }
  },
  dataLabels: {
    enabled: false
  },
  stroke: {
    curve: 'straight'
  },
  
  markers: {
    size: 0
  },
  xaxis: {
    categories: packs_num,
  },
  yaxis: {
    labels: {},
    title: {
      text: 'Высота'
    },
  },
  title: {
    text: 'График высоты',
    align: 'center'
  },
  legend: {
    show: false
  },
};
var press_graph = {
  series: [{
    data: vals.press
  }],
  chart: {
  id: 'realtime',
  height: 350,
  type: 'line',
  animations: {
    enabled: true,
    easing: 'linear',
    dynamicAnimation: {
      speed: 1000
    }
  },
  toolbar: {
    show: false
  },
  zoom: {
    enabled: false
  }
  },
  dataLabels: {
    enabled: false
  },
  stroke: {
    curve: 'straight'
  },
  
  markers: {
    size: 0
  },
  xaxis: {
    categories: packs_num,
  },
  title: {
    text: 'График давления',
    align: 'center'
  },
  legend: {
    show: false
  },
};
var acc_graph = {
  series: [{
    data: vals.acc
  }],
  chart: {
  id: 'realtime',
  height: 350,
  type: 'line',
  animations: {
    enabled: true,
    easing: 'linear',
    dynamicAnimation: {
      speed: 1000
    }
  },
  toolbar: {
    show: false
  },
  zoom: {
    enabled: false
  }
  },
  dataLabels: {
    enabled: false
  },
  stroke: {
    curve: 'straight'
  },
  
  markers: {
    size: 0
  },
  xaxis: {
    categories: packs_num,
  },
  title: {
    text: 'График ускорения',
    align: 'center'
  },
  legend: {
    show: false
  },
};
var temp_graph = {
  series: [{
    data: vals.temp
  }],
  chart: {
  id: 'realtime',
  height: 350,
  type: 'line',
  animations: {
    enabled: true,
    easing: 'linear',
    dynamicAnimation: {
      speed: 1000
    }
  },
  toolbar: {
    show: false
  },
  zoom: {
    enabled: false
  }
  },
  dataLabels: {
    enabled: false
  },
  stroke: {
    curve: 'straight'
  },
  
  markers: {
    size: 0
  },
  xaxis: {
    categories: packs_num,
  },
  title: {
    text: 'График температуры',
    align: 'center'
  },
  legend: {
    show: false
  },
};

function update_data(pack, height, press, acc, temp) {
  packs_num.push(pack);
  vals.height.push(height);
  vals.press.push(press);
  vals.acc.push(acc);
  vals.temp.push(temp);

  let height_rend = new ApexCharts(document.querySelector("#height_graph"), Object.assign(height_graph, options));
  let press_rend = new ApexCharts(document.querySelector("#press_graph"), Object.assign(press_graph, options));
  let acc_rend = new ApexCharts(document.querySelector("#acc_graph"), Object.assign(acc_graph, options));
  let temp_rend = new ApexCharts(document.querySelector("#temp_graph"), Object.assign(temp_graph, options));

  height_rend.render();
  press_rend.render();
  acc_rend.render();
  temp_rend.render();
}

export {update_data}
